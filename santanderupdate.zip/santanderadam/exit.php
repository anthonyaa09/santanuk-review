<?php
//echo 'meow';
include 'files/config.php';
header("location:$exit_link");
?>